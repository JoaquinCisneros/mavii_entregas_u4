#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <box2d/box2d.h>
#include "SFMLRenderer.h"
#include "Box2DHelper.h"

class Ragdoll {
private:
	b2Body* headBody;
	b2Body* trunkBody;
	b2Body* leftArmBody;
	b2Body* rightArmBody;
	b2Body* leftLegBody;
	b2Body* rightLegBody;

	b2DistanceJoint* headJoint;
	b2DistanceJoint* leftArmJoint;
	b2DistanceJoint* rightArmJoint;
	b2DistanceJoint* leftLegJoint;
	b2DistanceJoint* rightLegJoint;

public:
	Ragdoll(b2World* world, const b2Vec2& position);
	void ApplyForceToBody(b2Vec2& force);
	void DrawRagdoll();
};
