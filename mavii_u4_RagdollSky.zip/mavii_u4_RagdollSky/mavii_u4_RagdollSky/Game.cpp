#include "Game.h"
#include "Box2DHelper.h"

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
    // Inicializaci�n de la ventana de renderizado
    wnd = new RenderWindow(VideoMode(ancho, alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    SetZoom(); // Configuraci�n del zoom de la c�mara
    InitPhysics(); // Inicializaci�n del mundo f�sico
}

// M�todo principal que maneja el bucle del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpia la ventana con un color especificado
        DoEvents(); // Procesa los eventos del sistema
        UpdatePhysics(); // Actualiza la simulaci�n f�sica
        DrawGame(); // Dibuja el juego en la ventana
        wnd->display(); // Muestra la ventana renderizada
    }
}

// Actualiza la simulaci�n f�sica
void Game::UpdatePhysics()
{
    phyWorld->Step(frameTime, 8, 8); // Avanza la simulaci�n f�sica
    phyWorld->ClearForces(); // Limpia las fuerzas aplicadas a los cuerpos
    phyWorld->DebugDraw(); // Dibuja el mundo f�sico (para depuraci�n)

}

// Dibuja los elementos del juego en la ventana
void Game::DrawGame()
{
    // Dibujamos el suelo y las paredes
    sf::RectangleShape groundShape(sf::Vector2f(100, 5));
    groundShape.setFillColor(sf::Color::Red);
    groundShape.setPosition(50, 100);
    groundShape.setOrigin(50, 2.5f);
    wnd->draw(groundShape);

    sf::RectangleShape leftWallShape(sf::Vector2f(5, 100));
    leftWallShape.setFillColor(sf::Color::Red);
    leftWallShape.setPosition(0, 50);
    leftWallShape.setOrigin(2.5f, 50.0f);
    wnd->draw(leftWallShape);

    sf::RectangleShape rightWallShape(sf::Vector2f(5, 100));
    rightWallShape.setFillColor(sf::Color::Red);
    rightWallShape.setPosition(100, 50);
    rightWallShape.setOrigin(2.5f, 50.0f);
    wnd->draw(rightWallShape);

    sf::RectangleShape topWallShape(sf::Vector2f(100, 5));
    topWallShape.setFillColor(sf::Color::Red);
    topWallShape.setPosition(50, 0);
    topWallShape.setOrigin(50.0f, 2.5f);
    wnd->draw(topWallShape);

    //dibujo el ca�on
    sf::RectangleShape canyon(sf::Vector2f(15.0f, 8.0f));
    canyon.setFillColor(sf::Color::Magenta);
    canyon.setPosition(canyonBody->GetPosition().x, canyonBody->GetPosition().y);
    canyon.setOrigin(7.5f, 4.0f);

    //ajusto el angulo para que coincida con el body

    float angleInRadians = canyonBody->GetAngle();
    canyon.setRotation(canyonBody->GetAngle() * 180 / b2_pi);

    wnd->draw(canyon);

}

// Procesa los eventos del sistema
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::Closed:
            wnd->close(); // Cierra la ventana
            break;
        case Event::KeyPressed:
            //Imputs del usuario
        case Event::MouseButtonPressed:

            //DISPARO

            // Obtiene la posici�n del clic del mouse en coordenadas de ventana
            Vector2f mousePos(evt.mouseButton.x, evt.mouseButton.y);

            // Obtiene la posici�n del ca��n en el mundo
            b2Vec2 canyonPos = canyonBody->GetPosition();

            // Escala el vector de posici�n del ca��n para convertirlo a p�xeles
            b2Vec2 canyonPosInPixels = b2Vec2(canyonPos.x, canyonPos.y);

            // Convierte las coordenadas del mouse (en p�xeles) a coordenadas del mundo
            b2Vec2 worldMousePos = b2Vec2(wnd->mapPixelToCoords(Vector2i(evt.mouseButton.x, evt.mouseButton.y)).x,
                wnd->mapPixelToCoords(Vector2i(evt.mouseButton.x, evt.mouseButton.y)).y);

            // Calcula la direcci�n desde el ca��n hacia el punto de clic del mouse
            b2Vec2 direction = worldMousePos - canyonPos;

            // Calcula la distancia entre el ca��n y el punto de clic del mouse
            float distance = direction.Normalize();

            // Ajusta el �ngulo del ca��n hacia la direcci�n del clic del mouse
            float angle = atan2(direction.y, direction.x);
            canyonBody->SetTransform(canyonBody->GetPosition(), angle);

            // Define la magnitud de la fuerza en funci�n de la distancia
            float forceMagnitude = 500.0f * (1.0f - distance);

            // Aplica la fuerza en la direcci�n del clic del mouse
            b2Vec2 force = forceMagnitude * direction;

            // Calcula la posici�n de spawn del ragdoll
            b2Vec2 spawnPos(canyonBody->GetPosition().x + 10, canyonBody->GetPosition().y - 10);

            //Los ragdolls salian impulzados hacia la esquina contraria, asi que invertimos las fuerzas antes de pasarlas por parametro

            b2Vec2 finaleForce(-force.x, -force.y);
            // Dispara el ragdoll con la fuerza calculada
            ShootRagdoll(spawnPos, finaleForce);

            break;
        }
    }

}

// Configura el �rea visible en la ventana de renderizado
void Game::SetZoom()
{
    View camara;
    camara.setSize(100.0f, 100.0f); // Tama�o del �rea visible
    camara.setCenter(50.0f, 50.0f); // Centra la vista en estas coordenadas
    wnd->setView(camara); // Asigna la vista a la ventana
}

// Inicializa el mundo f�sico y los elementos est�ticos del juego
void Game::InitPhysics()
{
    // Inicializa el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

    // Inicializa el renderizador de depuraci�n para el mundo f�sico

    debugRender = new SFMLRenderer(wnd);
    debugRender->SetFlags(UINT_MAX); // Configura el renderizado para que muestre todo
    phyWorld->SetDebugDraw(debugRender);

    // Crea los elementos est�ticos del juego (suelo y paredes)

    b2Body* topWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 5);
    topWallBody->SetTransform(b2Vec2(50.0f, 0.0f), 0.0f);
    b2Body* groundBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 5);
    groundBody->SetTransform(b2Vec2(50.0f, 100.0f), 0.0f);
    b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 5, 100);
    leftWallBody->SetTransform(b2Vec2(0.0f, 50.0f), 0.0f);
    b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 5, 100);
    rightWallBody->SetTransform(b2Vec2(100.0f, 50.0f), 0.0);

    //CA�ON

    //Setear body del ca�on

    canyonBody = Box2DHelper::CreateRectangularKinematicBody(phyWorld, 15.0f, 8.0f);
    canyonBody->SetTransform(b2Vec2(15.0f, 85.0f), 0);

    //OBSTACULOS

    //Fijos

    b2Body* topRigidObstacle = Box2DHelper::CreateRectangularStaticBody(phyWorld, 4.0f, 30.0f);
    topRigidObstacle->SetTransform(b2Vec2(55.0f, 15.0f), 0);
    b2Body* botRigidObstacle = Box2DHelper::CreateRectangularStaticBody(phyWorld, 4.0f, 40.0f);
    botRigidObstacle->SetTransform(b2Vec2(55.0f, 80.0f), 0);

    //Dinamicos

    //Plataforma

    b2Body* platform1 = Box2DHelper::CreateRectangularStaticBody(phyWorld, 20.0f, 20.0f);
    platform1->SetTransform(b2Vec2(85.0f, 90.0f), 0);

    //Objeto movible

    b2Body* dynamicObstacle = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 7.0f, 15.0f, 0.1f, 0.3f, 0.1f);
    dynamicObstacle->SetTransform(b2Vec2(85.0f, 70.0f), 0.0f);

}

void Game::ShootRagdoll(b2Vec2& position, b2Vec2& force) {
    Ragdoll ragdoll(phyWorld, position);

    ragdoll.ApplyForceToBody(force);
}

