#include "Game.h"
#include "Box2DHelper.h"

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
    // Inicializaci�n de la ventana de renderizado
    wnd = new RenderWindow(VideoMode(ancho, alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    SetZoom(); // Configuraci�n del zoom de la c�mara
    InitPhysics(); // Inicializaci�n del mundo f�sico
}

// M�todo principal que maneja el bucle del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpia la ventana con un color especificado
        DoEvents(); // Procesa los eventos del sistema
        UpdatePhysics(); // Actualiza la simulaci�n f�sica
        DrawGame(); // Dibuja el juego en la ventana
        wnd->display(); // Muestra la ventana renderizada
    }
}

// Actualiza la simulaci�n f�sica
void Game::UpdatePhysics()
{
    phyWorld->Step(frameTime, 8, 8); // Avanza la simulaci�n f�sica
    phyWorld->ClearForces(); // Limpia las fuerzas aplicadas a los cuerpos
    phyWorld->DebugDraw(); // Dibuja el mundo f�sico (para depuraci�n)

}

// Dibuja los elementos del juego en la ventana
void Game::DrawGame()
{
    // Dibujamos el suelo y las paredes
    sf::RectangleShape groundShape(sf::Vector2f(100, 5));
    groundShape.setFillColor(sf::Color::Red);
    groundShape.setPosition(50, 100);
    groundShape.setOrigin(50, 2.5f);
    wnd->draw(groundShape);

    sf::RectangleShape leftWallShape(sf::Vector2f(5, 100));
    leftWallShape.setFillColor(sf::Color::Red);
    leftWallShape.setPosition(0, 50);
    leftWallShape.setOrigin(2.5f, 50.0f);
    wnd->draw(leftWallShape);

    sf::RectangleShape rightWallShape(sf::Vector2f(5, 100));
    rightWallShape.setFillColor(sf::Color::Red);
    rightWallShape.setPosition(100, 50);
    rightWallShape.setOrigin(2.5f, 50.0f);
    wnd->draw(rightWallShape);

    sf::RectangleShape topWallShape(sf::Vector2f(100, 5));
    topWallShape.setFillColor(sf::Color::Red);
    topWallShape.setPosition(50, 0);
    topWallShape.setOrigin(50.0f, 2.5f);
    wnd->draw(topWallShape);

    //Dibujo del ragdoll

    sf::RectangleShape headShape(sf::Vector2f(3.0f, 3.0f));
    headShape.setFillColor(sf::Color::Blue);
    headShape.setOrigin(1.5f, 1.5f);
    headShape.setRotation(headBody->GetAngle() * 180 / b2_pi);
    headShape.setPosition(headBody->GetPosition().x, headBody->GetPosition().y);
    wnd->draw(headShape);

    //torso

    sf::RectangleShape trunkShape(sf::Vector2f(6.0f, 8.0f));
    trunkShape.setFillColor(sf::Color::Yellow);
    trunkShape.setOrigin(3.0f, 4.0f);
    trunkShape.setRotation(trunkBody->GetAngle() * 180 / b2_pi);
    trunkShape.setPosition(trunkBody->GetPosition().x, trunkBody->GetPosition().y);
    wnd->draw(trunkShape);

    //brazos

    sf::RectangleShape leftArmShape(sf::Vector2f(2.0f, 6.0f));
    leftArmShape.setFillColor(sf::Color::Green);
    leftArmShape.setOrigin(1.0f, 3.0f);
    leftArmShape.setRotation(leftArmBody->GetAngle() * 180 / b2_pi);
    leftArmShape.setPosition(leftArmBody->GetPosition().x, leftArmBody->GetPosition().y);
    wnd->draw(leftArmShape);

    sf::RectangleShape rightArmShape(sf::Vector2f(2.0f, 6.0f));
    rightArmShape.setFillColor(sf::Color::Green);
    rightArmShape.setOrigin(1.0f, 3.0f);
    rightArmShape.setRotation(rightArmBody->GetAngle() * 180 / b2_pi);
    rightArmShape.setPosition(rightArmBody->GetPosition().x, rightArmBody->GetPosition().y);
    wnd->draw(rightArmShape);

    //piernas

    sf::RectangleShape leftLegShape(sf::Vector2f(2.6f, 8.0f));
    leftLegShape.setFillColor(sf::Color::Green);
    leftLegShape.setOrigin(1.3f, 4.0f);
    leftLegShape.setRotation(leftLegBody->GetAngle() * 180 / b2_pi);
    leftLegShape.setPosition(leftLegBody->GetPosition().x, leftLegBody->GetPosition().y);
    wnd->draw(leftLegShape);

    sf::RectangleShape rightLegShape(sf::Vector2f(2.6f, 8.0f));
    rightLegShape.setFillColor(sf::Color::Green);
    rightLegShape.setOrigin(1.3f, 4.0f);
    rightLegShape.setRotation(rightLegBody->GetAngle() * 180 / b2_pi);
    rightLegShape.setPosition(rightLegBody->GetPosition().x, rightLegBody->GetPosition().y);
    wnd->draw(rightLegShape);

}

// Procesa los eventos del sistema
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::Closed:
            wnd->close(); // Cierra la ventana
            break;
        case Event::KeyPressed:
            //Imputs del usuario
            if (evt.key.code == Keyboard::Space) {
                headBody->ApplyLinearImpulseToCenter(b2Vec2(0.0f, -500.0f), true);
            }

            break;
        }
    }

}

// Configura el �rea visible en la ventana de renderizado
void Game::SetZoom()
{
    View camara;
    camara.setSize(100.0f, 100.0f); // Tama�o del �rea visible
    camara.setCenter(50.0f, 50.0f); // Centra la vista en estas coordenadas
    wnd->setView(camara); // Asigna la vista a la ventana
}

// Inicializa el mundo f�sico y los elementos est�ticos del juego
void Game::InitPhysics()
{
    // Inicializa el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

    // Inicializa el renderizador de depuraci�n para el mundo f�sico

    debugRender = new SFMLRenderer(wnd);
    debugRender->SetFlags(UINT_MAX); // Configura el renderizado para que muestre todo
    phyWorld->SetDebugDraw(debugRender);

    // Crea los elementos est�ticos del juego (suelo y paredes)

    b2Body* topWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 5);
    topWallBody->SetTransform(b2Vec2(50.0f, 0.0f), 0.0f);
    b2Body* groundBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 5);
    groundBody->SetTransform(b2Vec2(50.0f, 100.0f), 0.0f);
    b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 5, 100);
    leftWallBody->SetTransform(b2Vec2(0.0f, 50.0f), 0.0f);
    b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 5, 100);
    rightWallBody->SetTransform(b2Vec2(100.0f, 50.0f), 0.0);

    //Cuerpo
    
    headBody = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 3.0f, 3.0f, 1.0f, 0.3f, 0.1f);
    headBody->SetTransform(b2Vec2(50.0f, 51.0f), 0.0f);

    trunkBody = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 6.0f, 8.0f, 1.0f, 0.0f, 0.1f);
    trunkBody->SetTransform(b2Vec2(50.0f, 57.0f), 0.0f);

    leftArmBody = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 2.0f, 6.0f, 1.0f, 0.0f, 0.1f);
    leftArmBody->SetTransform(b2Vec2(46.0f, 55.0f), 0.0f);

    rightArmBody = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 2.0f, 6.0f, 1.0f, 0.0f, 0.1f);
    rightArmBody->SetTransform(b2Vec2(54.0f, 55.0f), 0.0f);

    leftLegBody = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 2.6f, 8.0f, 1.0f, 0.0f, 0.1f);
    leftLegBody->SetTransform(b2Vec2(47.5f, 66.0f), 0);

    rightLegBody = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 2.6f, 8.0f, 1.0f, 0.0f, 0.1f);
    rightLegBody->SetTransform(b2Vec2(52.5f, 66.0f), 0);

    //Joints

    b2DistanceJoint* headJoint = Box2DHelper::CreateDistanceJoint(phyWorld, trunkBody, b2Vec2(trunkBody->GetPosition().x, trunkBody->GetPosition().y - 3)
                                                                , headBody, b2Vec2(headBody->GetPosition().x, headBody->GetPosition().y + 2), 0.0f, 0.5f, 0.1f);

    b2DistanceJoint* leftArmJoint = Box2DHelper::CreateDistanceJoint(phyWorld, trunkBody, b2Vec2(trunkBody->GetPosition().x - 2, trunkBody->GetPosition().y - 4)
                                                                   , leftArmBody, b2Vec2(leftArmBody->GetPosition().x + 1, leftArmBody->GetPosition().y - 2), 0.0f, 0.5f, 0.1f);

    b2DistanceJoint* rightArmJoint = Box2DHelper::CreateDistanceJoint(phyWorld, trunkBody, b2Vec2(trunkBody->GetPosition().x + 2, trunkBody->GetPosition().y - 4)
                                                                    , rightArmBody, b2Vec2(rightArmBody->GetPosition().x - 1, rightArmBody->GetPosition().y - 2), 0.0f, 0.5f, 0.1f);

    b2DistanceJoint* leftLegJoint = Box2DHelper::CreateDistanceJoint(phyWorld, trunkBody, b2Vec2(trunkBody->GetPosition().x - 1, trunkBody->GetPosition().y + 4)
                                                                   , leftLegBody, b2Vec2(leftLegBody->GetPosition().x + 1.3f, leftLegBody->GetPosition().y - 4), 0.0f, 0.5f, 0.1f);

    b2DistanceJoint* rightLegJoint = Box2DHelper::CreateDistanceJoint(phyWorld, trunkBody, b2Vec2(trunkBody->GetPosition().x + 1, trunkBody->GetPosition().y + 4)
                                                                    , rightLegBody, b2Vec2(rightLegBody->GetPosition().x - 1.3f, rightLegBody->GetPosition().y - 4), 0.0f, 0.5f, 0.1f);
}

