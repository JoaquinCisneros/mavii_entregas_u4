#include "Ragdoll.h"

Ragdoll::Ragdoll(b2World* world, const b2Vec2& position) {

    //Cuerpo

    headBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.0f, 1.0f, 0.3f, 0.3f, 0.1f);
    headBody->SetTransform(b2Vec2(position.x, position.y - 3), 0.0f);

    trunkBody = Box2DHelper::CreateRectangularDynamicBody(world, 2.0f, 4.0f, 0.3f, 0.0f, 0.1f);
    trunkBody->SetTransform(b2Vec2(position), 0.0f);

    leftArmBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.0f, 2.0f, 0.3f, 0.0f, 0.1f);
    leftArmBody->SetTransform(b2Vec2(position.x - 2, position.y), 0.0f);

    rightArmBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.0f, 2.0f, 0.3f, 0.0f, 0.1f);
    rightArmBody->SetTransform(b2Vec2(position.x + 2, position.y), 0.0f);

    leftLegBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.2f, 4.0f, 0.3f, 0.0f, 0.1f);
    leftLegBody->SetTransform(b2Vec2(position.x -0.5f, position.y + 4), 0);

    rightLegBody = Box2DHelper::CreateRectangularDynamicBody(world, 1.2f, 4.0f, 0.3f, 0.0f, 0.1f);
    rightLegBody->SetTransform(b2Vec2(position.x +0.5f, position.y +4), 0);

    //Joints

    headJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x, trunkBody->GetPosition().y - 2),
        headBody, b2Vec2(headBody->GetPosition().x, headBody->GetPosition().y + 0.5f), 0.5f, 1.0f, 1.0f);

    leftArmJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x - 1, trunkBody->GetPosition().y - 2),
        leftArmBody, b2Vec2(leftArmBody->GetPosition().x, leftArmBody->GetPosition().y - 1), 0.5f, 1.0f, 1.0f);

    rightArmJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x + 1, trunkBody->GetPosition().y - 2),
        rightArmBody, b2Vec2(rightArmBody->GetPosition().x, rightArmBody->GetPosition().y - 1), 0.5f, 1.0f, 1.0f);

    leftLegJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x - 1, trunkBody->GetPosition().y + 2),
        leftLegBody, b2Vec2(leftLegBody->GetPosition().x, leftLegBody->GetPosition().y - 1.5f), 0.5f, 1.0f, 1.0f);

    rightLegJoint = Box2DHelper::CreateDistanceJoint(world, trunkBody, b2Vec2(trunkBody->GetPosition().x + 1, trunkBody->GetPosition().y + 2),
        rightLegBody, b2Vec2(rightLegBody->GetPosition().x, rightLegBody->GetPosition().y - 1.5f), 0.5f, 1.0f, 1.0f);

}

void Ragdoll::ApplyForceToBody(b2Vec2& force) {
    trunkBody->ApplyForceToCenter(b2Vec2(force), true);
}

void Ragdoll::DrawRagdoll() {
    //Dibujo del ragdoll

    sf::RectangleShape headShape(sf::Vector2f(1.0f, 1.0f));
    headShape.setFillColor(sf::Color::Blue);
    headShape.setOrigin(headShape.getSize().x / 2, headShape.getSize().y / 2);
    headShape.setRotation(headBody->GetAngle() * 180 / b2_pi);
    headShape.setPosition(headBody->GetPosition().x, headBody->GetPosition().y);
    //wnd->draw(headShape);

    //torso

    sf::RectangleShape trunkShape(sf::Vector2f(2.0f, 4.0f));
    trunkShape.setFillColor(sf::Color::Yellow);
    trunkShape.setOrigin(trunkShape.getSize().x / 2, trunkShape.getSize().y / 2);
    trunkShape.setRotation(trunkBody->GetAngle() * 180 / b2_pi);
    trunkShape.setPosition(trunkBody->GetPosition().x, trunkBody->GetPosition().y);
    //wnd->draw(trunkShape);

    //brazos

    sf::RectangleShape leftArmShape(sf::Vector2f(1.0f, 2.0f));
    leftArmShape.setFillColor(sf::Color::Green);
    leftArmShape.setOrigin(leftArmShape.getSize().x / 2, leftArmShape.getSize().y / 2);
    leftArmShape.setRotation(leftArmBody->GetAngle() * 180 / b2_pi);
    leftArmShape.setPosition(leftArmBody->GetPosition().x, leftArmBody->GetPosition().y);
    //wnd->draw(leftArmShape);

    sf::RectangleShape rightArmShape(sf::Vector2f(1.0f, 2.0f));
    rightArmShape.setFillColor(sf::Color::Green);
    rightArmShape.setOrigin(rightArmShape.getSize().x / 2, rightArmShape.getSize().y / 2);
    rightArmShape.setRotation(rightArmBody->GetAngle() * 180 / b2_pi);
    rightArmShape.setPosition(rightArmBody->GetPosition().x, rightArmBody->GetPosition().y);
    //wnd->draw(rightArmShape);

    //piernas

    sf::RectangleShape leftLegShape(sf::Vector2f(1.2f, 4.0f));
    leftLegShape.setFillColor(sf::Color::White);
    leftLegShape.setOrigin(leftLegShape.getSize().x / 2, leftLegShape.getSize().y / 2);
    leftLegShape.setRotation(leftLegBody->GetAngle() * 180 / b2_pi);
    leftLegShape.setPosition(leftLegBody->GetPosition().x, leftLegBody->GetPosition().y);
    //wnd->draw(leftLegShape);

    sf::RectangleShape rightLegShape(sf::Vector2f(1.2f, 4.0f));
    rightLegShape.setFillColor(sf::Color::White);
    rightLegShape.setOrigin(rightLegShape.getSize().x / 2, rightLegShape.getSize().y / 2);
    rightLegShape.setRotation(rightLegBody->GetAngle() * 180 / b2_pi);
    rightLegShape.setPosition(rightLegBody->GetPosition().x, rightLegBody->GetPosition().y);
    //wnd->draw(rightLegShape);

}